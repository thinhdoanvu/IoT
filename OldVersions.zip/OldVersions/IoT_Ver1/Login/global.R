datane = read.csv("C:/Users/Administrator/Desktop/R/R_shiny/IoT_Ver1/Login/data/admissions.csv",header = TRUE, sep = ",")
datane$Date <- as.Date(datane$Date,format="%d/%m/%Y")
#Giai thich: trong file csv minh ky hieu: 05/05/2021 <=> minh hieu la: D/M/Y
#Ep R hieu day la du lieu Date voi dinh dang: D/M/Y
#Tu do R se tra ve gia tri la: 2021-05-05 (Y-M-D)
