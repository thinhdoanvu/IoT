shinyServer(function(input, output, session) {
    
    ####################################################################
    ################### SETTINGS tab panel ############################
    ####################################################################
    source("C:/Users/Administrator/Desktop/R/R_shiny/IoT_Ver4/Login/global.R")
    
    #Login Logout
    USER <- reactiveValues(Logged = FALSE , session = session$user) 
    source("www/Login.R",  local = TRUE)
    
    output$LoginPage <- renderUI({    
        if (USER$Logged == TRUE) {
            
            #Dang nhap thanh cong
            
            
            fluidRow(
                titlePanel(title = "PARAMETERS SETTINGS"), align = "center"
            )
            hr()
            uiOutput("Email")#hien thi GUI Email and Acceptable range
            
            
        }#End IF (login thanh cong)                 
    })  
    
    #--------------------------------------------------------------------------
    #Design UI for range value and Email
    rec_person=""
    output$Email <- renderUI({
        fluidRow(
            column(width = 3,style = "background-color:#CCCCCC;",
                   tags$h3("Email settings"),
                   hr(),
                   textInput("email_to", "TO:", value="itspider2018@gmail.com",),
            ),#End column 1
            
            column(width = 1),
            
            column(width = 4,style = "background-color:#FFCCCC;",
                   tags$h3("Acceptable ranges"),
                   hr(),
                   #Temperature
                   column(width = 12,
                          numericInput(inputId="temperature_min",label="Temperature MIN",value=25,min = 0,max = 100,step = 1,width = NULL),
                          numericInput(inputId="temperature_max",label="Temperature MAX",value=32,min = 0,max = 100,step = 1,width = NULL),
                   ),
                   
                   #pH
                   hr(),
                   column(width = 12,
                          numericInput(inputId="pH_min",label="pH MIN",value=7,min = 0,max = 10,step = 1,width = NULL),
                          numericInput(inputId="pH_max",label="PH MAX",value=9.5,min = 0,max = 10,step = 0.1,width = NULL),
                   ),
                   
                   #Dissolved Oxygen
                   hr(),
                   column(width = 12,
                          numericInput(inputId="Dissolved_Oxygen_min",label="Dissolved Oxygen MIN",value=33,min = 0,max = 100,step = 1,width = NULL),
                   ),
                   #Button
                    actionButton("Accept_datarange", "Accept!"),
                   hr()
            ),#End column2
        )#End FiluidRow for Email
    })#End Output Email   
    
    #--------------------------------------------------------------------------
    #Send Email fuction
    send.emails <- function(nguoinhan,noidung) {
        email <- gm_mime() %>%
            gm_to(nguoinhan) %>%
            gm_from("itspider2019@gmail.com") %>%
            gm_subject("NTU SmartAgri Alert message") %>%
            gm_text_body(noidung)
        gm_send_message(email)
    }#End function
    
    #Check condition
    ##Khai bao bien
        nd=""
        t_min=tail(head(read.table(paste0(path_datarange,"/www/datarange.txt")),2),1)
        t_max=tail(head(read.table(paste0(path_datarange,"/www/datarange.txt")),3),1)
        ph_min=tail(head(read.table(paste0(path_datarange,"/www/datarange.txt")),4),1)
        ph_max=tail(head(read.table(paste0(path_datarange,"/www/datarange.txt")),5),1)
        od_min=tail(head(read.table(paste0(path_datarange,"/www/datarange.txt")),6),1)
        
    if (datane_top$Temperature > t_max || datane_top$Temperature < t_min){
        nd = paste0(toupper("Temperature is out of range"), "\n\n","Temperature is: ", datane_top$Temperature, "\n", "pH is: ", datane_top$pH, "\n","Dissolved Oxygen is: ", datane_top$Dissolved_Oxygen)
        
    }
    else
    {
        if(datane_top$pH > ph_max || datane_top$pH < ph_min ){
            nd = paste0(toupper("pH is out of range"), "\n\n","Temperature is: ", datane_top$Temperature, "\n", "pH is: ", datane_top$pH, "\n","Dissolved Oxygen is: ", datane_top$Dissolved_Oxygen)
        }
        else
        {
            if(datane_top$Dissolved_Oxygen < od_min){
                nd = paste0(toupper("Dissolved Oxygen is below of acceptable range"), "\n\n","Temperature is: ", datane_top$Temperature, "\n", "pH is: ", datane_top$pH, "\n","Dissolved Oxygen is: ", datane_top$Dissolved_Oxygen) 
            }
        }
    }
    
    #Check and send mail
    observeEvent(nd, {
        if(nd!=""){
            #Doc noi dung file
            rec_person = tail(head(read.table(paste0(path_datarange,"/www/datarange.txt")),1),1)
            send.emails(rec_person,nd) 
        }
    })
    
    #Nhan nut Accept va tien hanh luu vao file
    
    observeEvent(input$Accept_datarange,{
        if(file.exists("www/datarange.txt")){
            file.remove("www/datarange.txt")
        }
        
        file.create("www/datarange.txt")
        write.table(input$email_to,"www/datarange.txt",sep = "",row.names=FALSE, col.names=FALSE, eol="\n", append =TRUE )
        write.table(input$temperature_min,"www/datarange.txt",sep = "",row.names=FALSE, col.names=FALSE, eol="\n", append =TRUE)
        write.table(input$temperature_max,"www/datarange.txt",sep = "",row.names=FALSE, col.names=FALSE, eol="\n", append =TRUE)
        write.table(input$pH_min,"www/datarange.txt",sep = "",row.names=FALSE, col.names=FALSE, eol="\n", append =TRUE)
        write.table(input$pH_max,"www/datarange.txt",sep = "",row.names=FALSE, col.names=FALSE, eol="\n", append =TRUE)
        write.table(input$Dissolved_Oxygen_min,"www/datarange.txt",sep = "",row.names=FALSE, col.names=FALSE, eol="\n", append =TRUE)
        shinyjs::disable("Accept_datarange")
    })
    
    ####################################################################
    ################### Statistic tab panel ############################
    ####################################################################
    
    ############loading file -------------------------------
    
    df_products_NOupload <- reactive({
        inFile <- input$target_upload
        inFile$datapath = paste0(getwd(),"/data")
        wd.init = getwd()
        setwd(inFile$datapath)
        df = read.csv("admissions.csv", header = input$header,sep = input$separator, quote=input$quote)
        setwd(wd.init)
        
        if (is.null(inFile))
            return(NULL)
        #df = read.csv(inFile$datapath, header = input$header,sep = input$separator, quote=input$quote)
        return(df)
    })
    
    df_products_upload <- reactive({
        inFile <- input$target_upload
        #inFile$datapath = paste0(getwd(),"/data")
        #wd.init = getwd()
        #setwd(inFile$datapath)
        #df = read.csv("admissions.csv", header = input$header,sep = input$separator, quote=input$quote)
        #setwd(wd.init)
        
        if (is.null(inFile))
            return(NULL)
        df = read.csv(inFile$datapath, header = input$header,sep = input$separator, quote=input$quote)
        return(df)
    })
    
    #Khi khong nhan nut Upload
    output$sample_table<- DT::renderDataTable({
        df <- df_products_NOupload()
        DT::datatable(df, options = list(lengthMenu = c(10, 25, 50), pageLength = 25))
    })
    
    #Khi nut Upload duoc nhan
    observeEvent(input$target_upload,{
        output$sample_table<- DT::renderDataTable({
            df <- df_products_upload()
            DT::datatable(df, options = list(lengthMenu = c(10, 25, 50), pageLength = 25))
        })
        shinyjs::enable("downloadData")
    })
    
    ############ downloading file
    
    shinyjs::disable("downloadData") # Tat nut Download cho den khi nhan nut Upload
    
    getData <- reactive({
        
        inFile <- input$target_upload
        if (is.null(input$target_upload))
            return(NULL)
        read.csv(inFile$datapath, header=input$header, sep=input$sep, 
                 quote=input$quote)
    })
    
    output$contents <- renderTable(
        getData()
    )
    
    output$downloadData <- downloadHandler(
        filename = function() { 
            paste("data-", Sys.Date(), ".csv", sep="")
        },
        content = function(file) {
            write.csv(getData(), file,sep = ',')
        })
    
    ############ Filtering 
    
    
    
    output$COL_VALUE <- renderUI({
        x <- datane %>% select(!!sym(input$COLUMN))
        selectInput("VALUE", "Value", choices = x)
    })
    
    output$COL_VALUE2 <- renderUI({
        x <- datane %>% select(!!sym(input$COLUMN2))
        selectInput("VALUE2", "Value", choices = x)
    })
    
    output$COL_VALUE3 <- renderUI({
        x <- datane %>% select(!!sym(input$COLUMN3))
        selectInput("VALUE3", "Value", choices = x)
    })
    
    
    output$the_data <- DT::renderDataTable({
        # To hide error when no value is selected
        
        #DK0
        my_data <- datane %>% filter(datane$Date >= input$dateRange[1] & datane$Date <= input$dateRange[2])
        #my_data <- filter(datane, between(datane$Date, as.Date("2021-05-05"), as.Date("2021-05-05")))
        
        #DK1
        if (input$VALUE == "") {
            my_data <- my_data 
        } else {
            my_data <- my_data %>% 
                filter(eval(parse(text = paste0(input$COLUMN, input$CONDITION, input$VALUE))))  
        }
        #DK2
        if (input$VALUE2 == "") {
            my_data <- my_data
        } else {
            my_data <- my_data %>% 
                filter(eval(parse(text = paste0(input$COLUMN2, input$CONDITION2, input$VALUE2))))  
        }
        #DK3
        if (input$VALUE3 == "") {
            my_data <- my_data
        } else {
            my_data <- my_data %>% 
                filter(eval(parse(text = paste0(input$COLUMN3, input$CONDITION3, input$VALUE3))))  
        }
        
        return(my_data)
        
        DT::datatable(my_data, options = list(lengthMenu = c(10, 25, 50), pageLength = 25))
    })
    
    ####################################################################
    ##################### HOME tab panel ###############################
    ####################################################################
    
    ##BOX
    
    output$TempBox <- renderValueBox({
        valueBox(datane_top$Temperature,'Temperature',icon = icon("thermometer"),color = "red") 
    })
    output$pHBox <- renderValueBox({
        valueBox(datane_top$pH,'PH',icon = NULL,color = "green") 
    })
    output$OxygenBox <- renderValueBox({
        valueBox(datane_top$Dissolved_Oxygen,'Dissolved Oxygen',icon = icon("percent"),color = "blue") 
    })
    
    
    ##CHART
    # observe({
    #     updateSelectInput(session, "temp_x", choices = (as.character(colnames(datane_20))),selected = "Time")
    # })
    # 
    # observe({
    #     updateSelectInput(session, "temp_y", choices = (as.character(colnames(datane_20))),selected = "Temperature")
    # })
    
    # output$Temperature <- renderPlot({
    #     ggplot(datane_20, aes(get(input$temp_x), get(input$temp_y))) + geom_point(colour = "red", size = 3) + labs(x="", y="")
    
    output$Temperature <- renderPlot({
        ggplot(datane_30, aes(Time, Temperature)) + geom_point(shape = 21, colour = "black", size = 7, fill = "red")
        # density1 <- density(datane_30$Temperature)
        # fig <- plot_ly(x = ~density1$x, y = ~density1$y, type = 'scatter', mode = 'lines', name = 'Fair cut', fill = 'tozeroy')
        # fig
    })
    
    output$pH <- renderPlot({
        ggplot(datane_30, aes(Time, pH)) + geom_point(shape = 23, colour = "black", size = 7, fill = "green")
        
    })
    
    output$Dissolved_Oxygen <- renderPlot({
        ggplot(datane_30, aes(Time, Dissolved_Oxygen)) + geom_point(shape = 24, colour = "black", size = 5, fill = "blue")
        
    })
    
    #Click mouse info on graph temperature
    temp_points <- reactiveValues(pts = NULL)
    observeEvent(input$temp_click, {
        x <- nearPoints(datane_30, input$temp_click, xvar = "Time", yvar = "Temperature")
        temp_points$pts <- x
    })
    
    output$temp_info <- renderPrint({
        temp_points$pts
    })
    
    #Click mouse info on graph pH
    pH_points <- reactiveValues(pts = NULL)
    observeEvent(input$pH_click, {
        x <- nearPoints(datane_30, input$pH_click, xvar = "Time", yvar = "pH")
        pH_points$pts <- x
    })
    
    output$pH_info <- renderPrint({
        pH_points$pts
    })
    
    #Click mouse info on graph Dissolved Oxygen
    Oxygen_points <- reactiveValues(pts = NULL)
    observeEvent(input$Oxygen_click, {
        x <- nearPoints(datane_30, input$Oxygen_click, xvar = "Time", yvar = "Dissolved_Oxygen")
        Oxygen_points$pts <- x
    })
    
    output$Oxygen_info <- renderPrint({
        Oxygen_points$pts
    })
    
    ####################################################################
    ##################### XXX tab panel ###############################
    ####################################################################
    
})