
library(shiny)
library(DBI)
library(dplyr)
library(openssl)

# Database ----------------------------------------------------------------

DB_NAME <- "data.sqlite"
TBL_USER_DATA <- "users"

DB_test_connect <- function(){
    db <- dbConnect(RSQLite::SQLite(), DB_NAME)
    
    print("#######################")
    print("- Connected to Database")
    
    # If a user data table doesn't already exist, create one
    if(!(TBL_USER_DATA %in% dbListTables(db))){
        print("- Warning: No 'users' table found. Creating table...")
        df <- data.frame(ID = as.numeric(character()),
                         USER = character(),
                         HASH = character(),
                         stringsAsFactors = FALSE)
        dbWriteTable(db, TBL_USER_DATA, df)
    } 
    
    print("- Table exists.")
    print("#######################")
    
    dbDisconnect(db)
}

DB_upload_csv <- function(filename, tblname){
    db <- dbConnect(RSQLite::SQLite(), DB_NAME)
    
    df <- read.csv(file = filename, header = T, row.names = F, stringsAsFactors = F)
    
    dbWriteTable(db, tblname, df)
    
    dbDisconnect(db)
}

DB_get_user <- function(user){
    db <- dbConnect(RSQLite::SQLite(), DB_NAME)
    
    users_data <- dbReadTable(db, TBL_USER_DATA)
    
    hashusers_data <- filter(users_data, USER == user)
    
    dbDisconnect(db)
    
    return(users_data)
}

DB_add_user <- function(usr, hsh){
    db <- dbConnect(RSQLite::SQLite(), DB_NAME)
    
    df <- dbReadTable(db, TBL_USER_DATA)
    
    q <- paste("INSERT INTO", TBL_USER_DATA, "(ID, USER, HASH) VALUEs (", paste("", nrow(df), ",", usr, ",", hsh, "", sep="'"), ")")
    
    #print(q)
    
    dbSendQuery(db, q)
    
    suppressWarnings({dbDisconnect(db)})
    
}

# Init Database -----------------------------------------------------------

DB_test_connect()

# Server ------------------------------------------------------------------

shinyServer(function(input, output, session) {
    
    loggedIn <- reactiveVal(value = FALSE)
    user <- reactiveVal(value = NULL)
    
    login <- eventReactive(input$login, {
        
        user_data <- DB_get_user(input$username)
        
        if(nrow(user_data) > 0){ # If the active user is in the DB then logged in
            if(sha256(input$password) == user_data[1, "HASH"]){
                
                user(input$username)
                loggedIn(TRUE)
                
                print(paste("- User:", user(), "logged in"))
                
                return(TRUE)
            }
        }
        
        return(FALSE)
        
    })
    register_user <- eventReactive(input$register_user, {
        
        users_data <- DB_get_user(input$new_user)
        
        if(nrow(users_data) > 0){
            return(span("User already exists", style = "color:red"))
        }
        
        new_hash <- sha256(input$new_pw)
        new_user <- input$new_user
        
        DB_add_user(new_user, new_hash)
        
        print("- New user added to database")
        
        return(span("New user registered", style = "color:green"))
        
    })
    
    output$register_status <- renderUI({
        if(input$register_user == 0){
            return(NULL)
        } else {
            register_user()
        }
    })
    output$login_status <- renderUI({
        if(input$login == 0){
            return(NULL)
        } else {
            if(!login()){
                return(span("The Username or Password is Incorrect", style = "color:red"))
            }
        }
    })
    
    observeEvent(input$create_login, {
        showModal(
            modalDialog(title = "Create Login", size = "m", 
                        textInput(inputId = "new_user", label = "Username"),
                        passwordInput(inputId = "new_pw", label = "Password"),
                        actionButton(inputId = "register_user", label = "Submit"),
                        p(input$register_user),
                        uiOutput("register_status")
                        
            )
        )
        
        register_user()
        
    })
    observeEvent(input$logout, {
        user(NULL)
        loggedIn(FALSE)
        print("- User: logged out")
    })
    
    observe({
        if(loggedIn()){
            output$NTU_SmartAgri <- renderUI({
                fluidPage(
                    fluidRow(
                        strong(paste("logged in as", user(), "|")), actionLink(inputId = "logout", "Logout"), align = "right",
                        hr()
                    ),
                    fluidRow(
                        titlePanel(title = "APP UI GOES Here"), align = "center"
                    )
                )
                
            })
        } else {
            output$NTU_SmartAgri <- renderUI({
                fluidPage(
                    fluidRow(
                        hr(),
                        titlePanel(title = "NTU SmartAgri"), align = "center"
                    ),
                    fluidRow(
                        column(4, offset = 4,
                               wellPanel(
                                   h2("Login", align = "center"),
                                   textInput(inputId = "username", label = "Username"),
                                   passwordInput(inputId = "password", label = "Password"),
                                   fluidRow(
                                       column(4, offset = 4, actionButton(inputId = "login", label = "Login")),
                                       column(8, offset =4, actionLink(inputId = "create_login", label = "Create user")),
                                       column(6, offset = 3, uiOutput(outputId = "login_status")
                                       )
                                   )
                               )
                        )
                    )
                )
            })
        }
    })
    
    ####################################################################
    ################### Statistic tab panel ############################
    ####################################################################
    
    ############loading file -------------------------------
    
    df_products_NOupload <- reactive({
        inFile <- input$target_upload
        inFile$datapath = paste0(getwd(),"/data")
        wd.init = getwd()
        setwd(inFile$datapath)
        df = read.csv("admissions.csv", header = input$header,sep = input$separator, quote=input$quote)
        setwd(wd.init)
        
        if (is.null(inFile))
            return(NULL)
        #df = read.csv(inFile$datapath, header = input$header,sep = input$separator, quote=input$quote)
        return(df)
    })
    
    df_products_upload <- reactive({
        inFile <- input$target_upload
        #inFile$datapath = paste0(getwd(),"/data")
        #wd.init = getwd()
        #setwd(inFile$datapath)
        #df = read.csv("admissions.csv", header = input$header,sep = input$separator, quote=input$quote)
        #setwd(wd.init)
        
        if (is.null(inFile))
            return(NULL)
        df = read.csv(inFile$datapath, header = input$header,sep = input$separator, quote=input$quote)
        return(df)
    })
    
    #Khi khong nhan nut Upload
    output$sample_table<- DT::renderDataTable({
        df <- df_products_NOupload()
        DT::datatable(df)
    })
    
    #Khi nut Upload duoc nhan
    observeEvent(input$target_upload,{
        output$sample_table<- DT::renderDataTable({
            df <- df_products_upload()
            DT::datatable(df)
        })
        shinyjs::enable("downloadData")
    })
    
    ############ downloading file
    
    shinyjs::disable("downloadData") # Tat nut Download cho den khi nhan nut Upload
    
    getData <- reactive({
        
        inFile <- input$target_upload
        if (is.null(input$target_upload))
            return(NULL)
        read.csv(inFile$datapath, header=input$header, sep=input$sep, 
                 quote=input$quote)
    })
    
    output$contents <- renderTable(
        getData()
    )
    
    output$downloadData <- downloadHandler(
        filename = function() { 
            paste("data-", Sys.Date(), ".csv", sep="")
        },
        content = function(file) {
            write.csv(getData(), file,sep = ',')
        })
    
    ############ Filtering 
    
    
    
    output$COL_VALUE <- renderUI({
        x <- datane %>% select(!!sym(input$COLUMN))
        selectInput("VALUE", "Value", choices = x)
    })
    
    output$COL_VALUE2 <- renderUI({
        x <- datane %>% select(!!sym(input$COLUMN2))
        selectInput("VALUE2", "Value", choices = x)
    })
    
    output$COL_VALUE3 <- renderUI({
        x <- datane %>% select(!!sym(input$COLUMN3))
        selectInput("VALUE3", "Value", choices = x)
    })
    
    
    output$the_data <- DT::renderDataTable({
        # To hide error when no value is selected
        
        #DK0
        my_data <- datane %>% filter(datane$Date >= input$dateRange[1] & datane$Date <= input$dateRange[2])
        #my_data <- filter(datane, between(datane$Date, as.Date("2021-05-05"), as.Date("2021-05-05")))
        
        #DK1
        if (input$VALUE == "") {
            my_data <- my_data 
        } else {
            my_data <- my_data %>% 
                filter(eval(parse(text = paste0(input$COLUMN, input$CONDITION, input$VALUE))))  
        }
        #DK2
        if (input$VALUE2 == "") {
            my_data <- my_data
        } else {
            my_data <- my_data %>% 
                filter(eval(parse(text = paste0(input$COLUMN2, input$CONDITION2, input$VALUE2))))  
        }
        #DK3
        if (input$VALUE3 == "") {
            my_data <- my_data
        } else {
            my_data <- my_data %>% 
                filter(eval(parse(text = paste0(input$COLUMN3, input$CONDITION3, input$VALUE3))))  
        }
        
        return(my_data)
       
        DT::datatable(my_data)
    })
    
    
})