library(shiny)
source("C:/Users/Administrator/Desktop/R/R_shiny/IoT_Ver1/Login/global.R")

ui <- navbarPage(
    
    "NTU SmartAgri",   
    
    #Tab HOME here----------------------------------------
    tabPanel("HOME",
             
             
             
        ),
    
    #Tab STATISTIC here----------------------------------------
    tabPanel("Statistic", 
             
             ## Side baner begin ---
             sidebarPanel(
                fileInput('target_upload', 'Choose file to upload',accept = c('text/csv','text/comma-separated-values','.csv')),
                
        
                radioButtons('separator', 'Separator',
                             c(Comma=',',
                               Semicolon=';',
                               Tab='\t'),selected=","),
                radioButtons('quote', 'Quote',
                             c(None='',
                               'Double Quote'='"',
                               'Single Quote'="'"),
                             selected=''),
                checkboxInput('header', 'Header', TRUE),
                
                downloadButton('downloadData', 'Download'),
                
                shinyjs::useShinyjs(),
                
                ),
             
             
             
             ## Side banner end!
                
             mainPanel(
                DT::dataTableOutput("sample_table")
                ),
             
             ## Filtering data
             
            # source("C:/Users/Administrator/Desktop/R/R_shiny/IoT/Login/global.R"),
             sidebarPanel(
                 
                 #DK0 
                 fluidRow(column(12,dateRangeInput('dateRange',
                                    label = 'Filter by date',
                                    start = as.Date('2021-05-05') , end = Sys.Date()#as.Date('2021-05-05')
                     ))),

                 #DK1
                 fluidRow(column(8, selectInput("COLUMN", "Filter By:", choices = c("",colnames(datane)[3:5]))), #tru 2 cot dau Date Time
                          column(6, selectInput("CONDITION", "Boolean", choices = c("==", "!=", ">=", "<="))),
                          column(6, uiOutput("COL_VALUE"))),
                 ##DK2
                 fluidRow(column(8, selectInput("COLUMN2", "Filter By:", choices = c("",colnames(datane)[3:5]))),
                          column(6, selectInput("CONDITION2", "Boolean", choices = c("==", "!=", ">=", "<="))),
                          column(6, uiOutput("COL_VALUE2"))),
                 ##DK3
                 fluidRow(column(8, selectInput("COLUMN3", "Filter By:", choices = c("",colnames(datane)[3:5]))),
                          column(6, selectInput("CONDITION3", "Boolean", choices = c("==", "!=", ">=", "<="))),
                          column(6, uiOutput("COL_VALUE3"))),
                 
                 
             ),
           
             
             hr(),
             mainPanel("Filtering data by value",
                 
                 hr(),
                 
                 DT::dataTableOutput("the_data")
             )
             
             
             #Tab STATISTIC end
             ),
    
    #Tab SETTINGS here----------------------------------------
    tabPanel("Settings", uiOutput("NTU_SmartAgri")),
    
    navbarMenu("News", 
               tabPanel("panel 4a", "sub-a"),
               tabPanel("panel 4b", "four-b"),
               tabPanel("panel 4c", "four-c")
    )
)

