#library(DBI)
library(openssl)
library(shinydashboard)
library(shiny)
library(dplyr)
library(ggplot2)
library(stringr)
library(DT)
library(shinyBS)
library(shinyjs)
library(shinycssloaders)
options(spinner.color="#006272")

library(gmailr)
gm_auth_configure(key="240677638712-a70r8lng6o91j48meb5ce4nj7ol2em65.apps.googleusercontent.com",secret = "1ndfdcQ3PDSkZNhDFsBR0_CN")

datane = read.csv("C:/Users/Administrator/Desktop/R/R_shiny/IoT_Ver3/Login/data/admissions.csv",header = TRUE, sep = ",")
datane$Date <- as.Date(datane$Date,format="%d/%m/%Y")
#Giai thich: trong file csv minh ky hieu: 05/05/2021 <=> minh hieu la: D/M/Y
#Ep R hieu day la du lieu Date voi dinh dang: D/M/Y
#Tu do R se tra ve gia tri la: 2021-05-05 (Y-M-D)
datane_30 <- head(datane,30)
datane_top <- head(datane,1)

#This is for Email
if(!file.exists("www/datarange.txt")){
  file.create("www/datarange.txt")
}

#library(highcharter)
#library(lubridate)
#library(WDI)
#library(geosphere)
#library(magrittr)
#library(timevis)
#library(withr)
#library(treemap)
#library(tidyr)