####################################################################
##################### SETTINGS tab panel ###############################
####################################################################

# Database ----------------------------------------------------------------

DB_NAME <- "data.sqlite"
TBL_USER_DATA <- "users"

DB_test_connect <- function(){
    db <- dbConnect(RSQLite::SQLite(), DB_NAME)
    
    print("#######################")
    print("- Connected to Database")
    
    # If a user data table doesn't already exist, create one
    if(!(TBL_USER_DATA %in% dbListTables(db))){
        print("- Warning: No 'users' table found. Creating table...")
        df <- data.frame(ID = as.numeric(character()),
                         USER = character(),
                         HASH = character(),
                         stringsAsFactors = FALSE)
        dbWriteTable(db, TBL_USER_DATA, df)
    } 
    
    print("- Table exists.")
    print("#######################")
    
    dbDisconnect(db)
}

DB_upload_csv <- function(filename, tblname){
    db <- dbConnect(RSQLite::SQLite(), DB_NAME)
    
    df <- read.csv(file = filename, header = T, row.names = F, stringsAsFactors = F)
    
    dbWriteTable(db, tblname, df)
    
    dbDisconnect(db)
}

DB_get_user <- function(user){
    db <- dbConnect(RSQLite::SQLite(), DB_NAME)
    
    users_data <- dbReadTable(db, TBL_USER_DATA)
    
    hashusers_data <- filter(users_data, USER == user)
    
    dbDisconnect(db)
    
    return(users_data)
}

DB_add_user <- function(usr, hsh){
    db <- dbConnect(RSQLite::SQLite(), DB_NAME)
    
    df <- dbReadTable(db, TBL_USER_DATA)
    
    q <- paste("INSERT INTO", TBL_USER_DATA, "(ID, USER, HASH) VALUEs (", paste("", nrow(df), ",", usr, ",", hsh, "", sep="'"), ")")
    
    #print(q)
    
    dbSendQuery(db, q)
    
    suppressWarnings({dbDisconnect(db)})
    
}

# Init Database -----------------------------------------------------------

DB_test_connect()

# Server ------------------------------------------------------------------

shinyServer(function(input, output, session) {
    
    loggedIn <- reactiveVal(value = FALSE)
    user <- reactiveVal(value = NULL)
    
    login <- eventReactive(input$login, {
        
        user_data <- DB_get_user(input$username)
        
        if(nrow(user_data) > 0){ # If the active user is in the DB then logged in
            if(sha256(input$password) == user_data[1, "HASH"]){
                
                user(input$username)
                loggedIn(TRUE)
                
                print(paste("- User:", user(), "logged in"))
                
                return(TRUE)
            }
        }
        
        return(FALSE)
        
    })
    register_user <- eventReactive(input$register_user, {
        
        users_data <- DB_get_user(input$new_user)
        
        if(nrow(users_data) > 0){
            return(span("User already exists", style = "color:red"))
        }
        
        new_hash <- sha256(input$new_pw)
        new_user <- input$new_user
        
        DB_add_user(new_user, new_hash)
        
        print("- New user added to database")
        
        return(span("New user registered", style = "color:green"))
        
    })
    
    output$register_status <- renderUI({
        if(input$register_user == 0){
            return(NULL)
        } else {
            register_user()
        }
    })
    output$login_status <- renderUI({
        if(input$login == 0){
            return(NULL)
        } else {
            if(!login()){
                return(span("The Username or Password is Incorrect", style = "color:red"))
            }
        }
    })
    
    observeEvent(input$create_login, {
        showModal(
            modalDialog(title = "Create Login", size = "m", 
                        textInput(inputId = "new_user", label = "Username"),
                        passwordInput(inputId = "new_pw", label = "Password"),
                        actionButton(inputId = "register_user", label = "Submit"),
                        p(input$register_user),
                        uiOutput("register_status")
                        
            )
        )
        
        register_user()
        
    })
    observeEvent(input$logout, {
        user(NULL)
        loggedIn(FALSE)
        print("- User: logged out")
    })
    
    observe({
        if(loggedIn()){
            output$NTU_SmartAgri <- renderUI({
                fluidPage(
                    fluidRow(
                        strong(paste("logged in as", user(), "|")), actionLink(inputId = "logout", "Logout"), align = "right",
                        hr()
                    ),
                    fluidRow(
                        titlePanel(title = "PARAMETER SETTINGS"), align = "center",
                        
                        #Login page thanh cong
                        output$Email <- renderUI({
                            sidebarPanel(
                                textInput("from", "From:", value=paste0(input$username,"@ntu.edu.vn")),
                                textInput("to", "To:", value="to@gmail.com"),
                                textInput("subject", "Subject:", value=""),
                                actionButton("send", "Send mail")
                            )#End sidebar
                            
                        })#End renderUI
                        
                        
                    )#Fluid End
                )
                
            })
        } else {
            output$NTU_SmartAgri <- renderUI({
                fluidPage(
                    fluidRow(
                        hr(),
                        titlePanel(title = "NTU SmartAgri"), align = "center"
                    ),
                    fluidRow(
                        column(4, offset = 4,
                               wellPanel(
                                   h2("Login", align = "center"),
                                   textInput(inputId = "username", label = "Username"),
                                   passwordInput(inputId = "password", label = "Password"),
                                   fluidRow(
                                       column(4, offset = 4, actionButton(inputId = "login", label = "Login")),
                                       column(8, offset =4, actionLink(inputId = "create_login", label = "Create user")),
                                       column(6, offset = 3, uiOutput(outputId = "login_status")
                                       )
                                   )
                               )
                        )
                    )
                )
            })
        }
    })
    
    ####################################################################
    ################### Statistic tab panel ############################
    ####################################################################
    
    ############loading file -------------------------------
    
    df_products_NOupload <- reactive({
        inFile <- input$target_upload
        inFile$datapath = paste0(getwd(),"/data")
        wd.init = getwd()
        setwd(inFile$datapath)
        df = read.csv("admissions.csv", header = input$header,sep = input$separator, quote=input$quote)
        setwd(wd.init)
        
        if (is.null(inFile))
            return(NULL)
        #df = read.csv(inFile$datapath, header = input$header,sep = input$separator, quote=input$quote)
        return(df)
    })
    
    df_products_upload <- reactive({
        inFile <- input$target_upload
        #inFile$datapath = paste0(getwd(),"/data")
        #wd.init = getwd()
        #setwd(inFile$datapath)
        #df = read.csv("admissions.csv", header = input$header,sep = input$separator, quote=input$quote)
        #setwd(wd.init)
        
        if (is.null(inFile))
            return(NULL)
        df = read.csv(inFile$datapath, header = input$header,sep = input$separator, quote=input$quote)
        return(df)
    })
    
    #Khi khong nhan nut Upload
    output$sample_table<- DT::renderDataTable({
        df <- df_products_NOupload()
        DT::datatable(df, options = list(lengthMenu = c(10, 25, 50), pageLength = 25))
    })
    
    #Khi nut Upload duoc nhan
    observeEvent(input$target_upload,{
        output$sample_table<- DT::renderDataTable({
            df <- df_products_upload()
            DT::datatable(df, options = list(lengthMenu = c(10, 25, 50), pageLength = 25))
        })
        shinyjs::enable("downloadData")
    })
    
    ############ downloading file
    
    shinyjs::disable("downloadData") # Tat nut Download cho den khi nhan nut Upload
    
    getData <- reactive({
        
        inFile <- input$target_upload
        if (is.null(input$target_upload))
            return(NULL)
        read.csv(inFile$datapath, header=input$header, sep=input$sep, 
                 quote=input$quote)
    })
    
    output$contents <- renderTable(
        getData()
    )
    
    output$downloadData <- downloadHandler(
        filename = function() { 
            paste("data-", Sys.Date(), ".csv", sep="")
        },
        content = function(file) {
            write.csv(getData(), file,sep = ',')
        })
    
    ############ Filtering 
    
    
    
    output$COL_VALUE <- renderUI({
        x <- datane %>% select(!!sym(input$COLUMN))
        selectInput("VALUE", "Value", choices = x)
    })
    
    output$COL_VALUE2 <- renderUI({
        x <- datane %>% select(!!sym(input$COLUMN2))
        selectInput("VALUE2", "Value", choices = x)
    })
    
    output$COL_VALUE3 <- renderUI({
        x <- datane %>% select(!!sym(input$COLUMN3))
        selectInput("VALUE3", "Value", choices = x)
    })
    
    
    output$the_data <- DT::renderDataTable({
        # To hide error when no value is selected
        
        #DK0
        my_data <- datane %>% filter(datane$Date >= input$dateRange[1] & datane$Date <= input$dateRange[2])
        #my_data <- filter(datane, between(datane$Date, as.Date("2021-05-05"), as.Date("2021-05-05")))
        
        #DK1
        if (input$VALUE == "") {
            my_data <- my_data 
        } else {
            my_data <- my_data %>% 
                filter(eval(parse(text = paste0(input$COLUMN, input$CONDITION, input$VALUE))))  
        }
        #DK2
        if (input$VALUE2 == "") {
            my_data <- my_data
        } else {
            my_data <- my_data %>% 
                filter(eval(parse(text = paste0(input$COLUMN2, input$CONDITION2, input$VALUE2))))  
        }
        #DK3
        if (input$VALUE3 == "") {
            my_data <- my_data
        } else {
            my_data <- my_data %>% 
                filter(eval(parse(text = paste0(input$COLUMN3, input$CONDITION3, input$VALUE3))))  
        }
        
        return(my_data)
        
        DT::datatable(my_data, options = list(lengthMenu = c(10, 25, 50), pageLength = 25))
    })
    
    ####################################################################
    ##################### HOME tab panel ###############################
    ####################################################################
    datane_30 <- head(datane,30)
    
    ##BOX
    datane_top <- head(datane,1)
    
    output$TempBox <- renderValueBox({
        valueBox(datane_top$Temperature,'Temperature',icon = icon("thermometer"),color = "red") 
    })
    output$pHBox <- renderValueBox({
        valueBox(datane_top$pH,'PH',icon = NULL,color = "green") 
    })
    output$OxygenBox <- renderValueBox({
        valueBox(datane_top$Dissolved_Oxygen,'Dissolved Oxygen',icon = icon("percent"),color = "blue") 
    })
    
    
    ##CHART
    # observe({
    #     updateSelectInput(session, "temp_x", choices = (as.character(colnames(datane_20))),selected = "Time")
    # })
    # 
    # observe({
    #     updateSelectInput(session, "temp_y", choices = (as.character(colnames(datane_20))),selected = "Temperature")
    # })
    
    # output$Temperature <- renderPlot({
    #     ggplot(datane_20, aes(get(input$temp_x), get(input$temp_y))) + geom_point(colour = "red", size = 3) + labs(x="", y="")
    
    output$Temperature <- renderPlot({
        ggplot(datane_30, aes(Time, Temperature)) + geom_point(shape = 21, colour = "black", size = 7, fill = "red")
        # density1 <- density(datane_30$Temperature)
        # fig <- plot_ly(x = ~density1$x, y = ~density1$y, type = 'scatter', mode = 'lines', name = 'Fair cut', fill = 'tozeroy')
        # fig
    })
    
    output$pH <- renderPlot({
        ggplot(datane_30, aes(Time, pH)) + geom_point(shape = 23, colour = "black", size = 7, fill = "green")
        
    })
    
    output$Dissolved_Oxygen <- renderPlot({
        ggplot(datane_30, aes(Time, Dissolved_Oxygen)) + geom_point(shape = 24, colour = "black", size = 5, fill = "blue")
        
    })
    
    #Click mouse info on graph temperature
    temp_points <- reactiveValues(pts = NULL)
    observeEvent(input$temp_click, {
        x <- nearPoints(datane_30, input$temp_click, xvar = "Time", yvar = "Temperature")
        temp_points$pts <- x
    })
    
    output$temp_info <- renderPrint({
        temp_points$pts
    })
    
    #Click mouse info on graph pH
    pH_points <- reactiveValues(pts = NULL)
    observeEvent(input$pH_click, {
        x <- nearPoints(datane_30, input$pH_click, xvar = "Time", yvar = "pH")
        pH_points$pts <- x
    })
    
    output$pH_info <- renderPrint({
        pH_points$pts
    })
    
    #Click mouse info on graph Dissolved Oxygen
    Oxygen_points <- reactiveValues(pts = NULL)
    observeEvent(input$Oxygen_click, {
        x <- nearPoints(datane_30, input$Oxygen_click, xvar = "Time", yvar = "Dissolved_Oxygen")
        Oxygen_points$pts <- x
    })
    
    output$Oxygen_info <- renderPrint({
        Oxygen_points$pts
    })
    
    ####################################################################
    ##################### XXX tab panel ###############################
    ####################################################################
    
})