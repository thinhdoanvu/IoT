source("C:/Users/Administrator/Desktop/R/R_shiny/IoT_Ver3/Login/global.R")

ui <- navbarPage(
    
    "NTU SmartAgri",   
    
    #---------------------------------------------------------------------------
    #---------------------------------------------------------------------------
    #Tab HOME here
    #---------------------------------------------------------------------------
    #---------------------------------------------------------------------------
    
    tabPanel("HOME",
             
             ##BOX
             ui <- dashboardPage(
                 dashboardHeader(title = "Real-Time value"),
                 dashboardSidebar(disable = TRUE, collapsed = TRUE,sidebarMenu()),
                 
                 dashboardBody(
                     fluidRow(
                         column(width = 12,
                                valueBoxOutput("TempBox", width = 4) %>% withSpinner(type=4),
                                valueBoxOutput("pHBox", width = 4),
                                valueBoxOutput("OxygenBox", width = 4),
                         ),
                     ),
                     
                     ## CHART 
                     
                     #plotOutput("plot1", click = "plot_click"),
                     #verbatimTextOutput("info")
                     # sidebarPanel(
                     #     fluidRow(
                     #         column(8,
                     #                div(style = "font-size: 13px;", selectInput("temp_x", label = "Select X axis", ''))
                     #         ),
                     #         tags$br(),
                     #         tags$br(),
                     #         column(8,
                     #                div(style = "font-size: 13px;", selectInput("temp_y", "Select Y axis", ''))
                     #         ))
                     #     
                     # ),
                     tabPanel("Graphics Page"),
                     mainPanel(width = 12, 
                               tabsetPanel(id='Graph',
                                           tabPanel("Temperature",tags$br(),plotOutput("Temperature", click = "temp_click"), verbatimTextOutput("temp_info")),
                                           tabPanel("pH",tags$br(),plotOutput("pH",click = "pH_click"),verbatimTextOutput("pH_info")),
                                           tabPanel("Dissolved_Oxygen",tags$br(),plotOutput("Dissolved_Oxygen",click = "Oxygen_click"),verbatimTextOutput("Oxygen_info"))
                                           
                               )), 
                     
                 ),
                 #End Body
                 
             ),
             
             #End UI Dashboard
        ),
    #Tab HOME end
    
    
    #---------------------------------------------------------------------------
    #---------------------------------------------------------------------------
    #Tab STATISTIC here
    #---------------------------------------------------------------------------
    #---------------------------------------------------------------------------
    
    tabPanel("Statistic", 
             
             ## Side baner begin ---
             sidebarPanel(
                 fileInput('target_upload', 'Choose file to upload',accept = c('text/csv','text/comma-separated-values','.csv')),
                 
                 
                 radioButtons('separator', 'Separator',
                              c(Comma=',',
                                Semicolon=';',
                                Tab='\t'),selected=","),
                 radioButtons('quote', 'Quote',
                              c(None='',
                                'Double Quote'='"',
                                'Single Quote'="'"),
                              selected=''),
                 checkboxInput('header', 'Header', TRUE),
                 
                 downloadButton('downloadData', 'Download'),
                 
                 shinyjs::useShinyjs(),
                 
                 hr(),
                 
                 #DK0 
                 fluidRow(column(12,dateRangeInput('dateRange',
                                                   label = 'Filter by date',
                                                   start = as.Date('2021-05-05') , end = Sys.Date()#as.Date('2021-05-05')
                 ))),
                 
                 #DK1
                 fluidRow(column(8, selectInput("COLUMN", "Filter By:", choices = c("",colnames(datane)[3:5]))), #tru 2 cot dau Date Time
                          column(6, selectInput("CONDITION", "Boolean", choices = c("==", "!=", ">=", "<="))),
                          column(6, uiOutput("COL_VALUE"))),
                 ##DK2
                 fluidRow(column(8, selectInput("COLUMN2", "Filter By:", choices = c("",colnames(datane)[3:5]))),
                          column(6, selectInput("CONDITION2", "Boolean", choices = c("==", "!=", ">=", "<="))),
                          column(6, uiOutput("COL_VALUE2"))),
                 ##DK3
                 fluidRow(column(8, selectInput("COLUMN3", "Filter By:", choices = c("",colnames(datane)[3:5]))),
                          column(6, selectInput("CONDITION3", "Boolean", choices = c("==", "!=", ">=", "<="))),
                          column(6, uiOutput("COL_VALUE3"))),
                 
             ),
             
             
             
             ## Side banner end!
             #An cai nay di neu khong ne se sinh ra 2 bang, xau!
             
             mainPanel(
                 #DT::dataTableOutput("sample_table")
                 
             ),
             
             ## Filtering data
             
             
             hr(),
             mainPanel("Filtering data by value",
                       
                       hr(),
                       
                       DT::dataTableOutput("the_data")
             )
             
             
             #Tab STATISTIC end
    ),
    #---------------------------------------------------------------------------
    #---------------------------------------------------------------------------
    #Tab SETTINGS here
    #---------------------------------------------------------------------------
    #---------------------------------------------------------------------------
    tabPanel("Settings", uiOutput("NTU_SmartAgri"),
             
             
             ),#END TabPanel
    #---------------------------------------------------------------------------
    #---------------------------------------------------------------------------
    #Tab SETTINGS END
    #---------------------------------------------------------------------------
    #---------------------------------------------------------------------------
    navbarMenu("News", 
               tabPanel("panel 4a", "sub-a"),
               tabPanel("panel 4b", "four-b"),
               tabPanel("panel 4c", "four-c")
    )
    
#MAIN CODE
)

